# Dark Planner — Android starter for group MOP-255

Dark-themed student planner with:
- Wake-up time: 07:20
- Leave for the bus: 07:50
- Commute: 30 minutes; estimated arrival: 08:20
- First standard pair starts: 08:30 (10-minute buffer)
- Bell schedule and the weekly subjects transcribed from the provided photos (`WeeklySchedule.kt`)
- A reminder form and Android notifications through `AlarmManager`

## Bell times
1. 08:30–09:50
2. 10:00–11:20
3. 11:50–13:10
4. 13:30–14:50
5. 15:00–16:20
6. 16:30–17:50

The photo also notes Monday “Разговоры о важном” at 09:00 and Thursday “Россия — мои горизонты” at 15:00.

## Build
1. Open this project in Android Studio.
2. Use JDK 17 and install Android SDK 35.
3. Let Gradle sync, then choose **Build > Build APK(s)**.
4. Install the resulting APK on the Android phone.

On Android 13+, grant notification permission. On Android 12+, exact alarms may require permission in system settings.

This starter is not yet a complete release app: reminders added through the form currently stay in memory only and reset when the app is restarted. Weekly data is provided in `WeeklySchedule.kt` for the next UI integration step.
