package com.example.darkplanner

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel("planner_reminders", "Planner reminders", NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val title = intent.getStringExtra("title") ?: "Напоминание"
        val body = intent.getStringExtra("body") ?: "Пора проверить план"
        val notification = NotificationCompat.Builder(context, "planner_reminders")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        manager.notify(intent.getIntExtra("id", 1), notification)
    }
}
