package com.example.darkplanner

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Calendar

private val Night = Color(0xFF10111A)
private val Panel = Color(0xFF1B1D2B)
private val Purple = Color(0xFF9B8CFF)
private val Muted = Color(0xFFAAAEC4)

data class PlannerItem(val title: String, val detail: String, val time: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Night, surface = Panel, primary = Purple,
                onBackground = Color.White, onSurface = Color.White
            )) {
                PlannerScreen(this)
            }
        }
    }
}

@Composable
fun PlannerScreen(context: Context) {
    var title by remember { mutableStateOf("") }
    var detail by remember { mutableStateOf("") }
    var time by remember { mutableStateOf("07:30") }
    var items by remember { mutableStateOf(listOf(
        PlannerItem("Выйти из дома", "Проверь ключи, телефон и проездной", "07:30"),
        PlannerItem("Первый урок", "Добавь расписание уроков", "08:30"),
        PlannerItem("Домашние задания", "Проверь задания на завтра", "17:00")
    )) }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    Column(
        Modifier.fillMaxSize().background(Night).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("DARK PLANNER", color = Purple, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Text("Твой день под контролем", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("Планируй уроки, дела и напоминания", color = Muted, fontSize = 14.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Сегодня", "Расписание", "Задачи").forEach {
                Surface(color = Panel, shape = RoundedCornerShape(18.dp)) {
                    Text(it, Modifier.padding(horizontal = 14.dp, vertical = 9.dp), color = if (it == "Сегодня") Purple else Muted)
                }
            }
        }
        Text("Ближайшие дела", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(items) { item ->
                Surface(color = Panel, shape = RoundedCornerShape(16.dp)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(item.time, color = Purple, fontWeight = FontWeight.Bold, modifier = Modifier.width(64.dp))
                        Column(Modifier.weight(1f)) {
                            Text(item.title, color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text(item.detail, color = Muted, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        Text("Добавить напоминание", fontWeight = FontWeight.SemiBold)
        OutlinedTextField(title, { title = it }, label = { Text("Что напомнить?") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(detail, { detail = it }, label = { Text("Подробности (необязательно)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(time, { time = it }, label = { Text("Время, например 07:30") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Button(
            onClick = {
                if (title.isNotBlank() && time.matches(Regex("\\d{2}:\\d{2}"))) {
                    val newItem = PlannerItem(title.trim(), detail.trim().ifBlank { "Напоминание" }, time)
                    items = items + newItem
                    scheduleReminder(context, newItem, items.size)
                    title = ""; detail = ""
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Purple, contentColor = Night)
        ) { Text("Добавить и включить уведомление", fontWeight = FontWeight.Bold) }
        Text("Напоминания срабатывают в заданное время. Для точных сигналов Android может попросить разрешение.", color = Muted, fontSize = 11.sp)
    }
}

fun scheduleReminder(context: Context, item: PlannerItem, id: Int) {
    val parts = item.time.split(":")
    val hour = parts[0].toIntOrNull() ?: return
    val minute = parts[1].toIntOrNull() ?: return
    if (hour !in 0..23 || minute !in 0..59) return
    val calendar = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
    }
    val intent = Intent(context, ReminderReceiver::class.java).apply {
        putExtra("title", item.title); putExtra("body", item.detail); putExtra("id", id)
    }
    val pending = PendingIntent.getBroadcast(context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    val alarms = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarms.canScheduleExactAlarms()) {
        context.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
    alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pending)
}
